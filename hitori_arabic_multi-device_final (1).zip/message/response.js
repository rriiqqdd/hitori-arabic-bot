
module.exports = {
  wait: '⌛ جاري المعالجة...',
  success: '✅ تم بنجاح!',
  error: '❌ حدث خطأ!',
  notFound: '⚠️ الأمر غير معروف',
  pleaseSendImage: '🖼️ الرجاء إرسال صورة',
};
